<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
// use App\Models\User;
// use App\Models\Client;
// use App\Models\Catchment;
// use App\Models\Transaction;
// use App\Models\Product_purchase_session;

class Activity extends Model
{
    use HasFactory;
    protected $guarded = [];

}
