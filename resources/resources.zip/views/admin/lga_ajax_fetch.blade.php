                                     <option value=""></option>
                                      @foreach ($lgas as $lga)
                                          
                                          <option value="{{$lga->name}}">{{$lga->name}}</option>
                                      @endforeach