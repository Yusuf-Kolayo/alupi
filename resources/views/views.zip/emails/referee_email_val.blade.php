<!DOCTYPE html>
<html>
<head>
    <title>Alupi</title>
</head>
<body>
    <h1>E-mail Verification</h1> 
    <h2>Your verification code is : </h2> <blockquote>{{$details['code']}}</blockquote> <br>  
    <h6>Now head back and complete the registration process</h6>
</body>
</html>